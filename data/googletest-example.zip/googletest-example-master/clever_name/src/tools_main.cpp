#include "clever_name/randomization.h"

int main() {
  return clever::GetXkcdRandomNumber();
}
