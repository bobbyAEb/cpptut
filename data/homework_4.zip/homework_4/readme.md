# Homework folder #
You have to add files to this homework.

- Create a CMake project in `digit_counter` folder.
- Create a single file `stack_limit.cpp` in `stack_limit` folder that outputs
  the memory you allocate on a stack to `stderr` when executed.
- Copy your `igg_image` project from previous homeworks and modify it to perform
  actions requested in the homework sheet.


# Structure of this folder #
```
homework_folder_4/
  |- digit_counter/
  |- stack_limit/
  |- igg_image/
```
