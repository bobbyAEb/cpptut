// Copyright Igor Bogoslavskyi, year 2018.
// In case of any problems with the code please contact me.
// Email: igor.bogoslavskyi@uni-bonn.de.

#include "clever_name/randomization.h"
#include <iostream>

namespace clever {

int GetXkcdRandomNumber() {
  return 4;  // Chosen by a fair dice roll.
             // Guaranteed to be random.
}

}  // namespace clever
